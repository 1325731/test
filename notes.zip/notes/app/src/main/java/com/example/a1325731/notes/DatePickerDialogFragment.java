package com.example.a1325731.notes;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.support.v4.app.DialogFragment;
import android.os.Bundle;

import java.util.Calendar;
import java.util.Date;

/**
 * A DatePickerDialogFragment customizable with default time and with user specified event handling
 *
 *  - based on class found in https://developer.android.com/guide/topics/ui/controls/pickers.html
 *
 * @author Ian Clement (ian.clement@johnabbott.qc.ca)
 */
public class DatePickerDialogFragment extends DialogFragment {

    // constants for bundling default hour/minute
    private static final String EXTRA_YEAR = "year";
    private static final String EXTRA_MONTH = "month";
    private static final String EXTRA_DAY_OF_MONTH = "day_of_month";

    // custom event listener
    private DatePickerDialog.OnDateSetListener listener;

    /**
     * Create a DatePickerDialogFragment with a default day, month and year, and an event listener.
     * @param start default date
     * @param listener event listener
     * @return
     */
    public static DatePickerDialogFragment createDatePicker(Date start, DatePickerDialog.OnDateSetListener listener) {
        DatePickerDialogFragment f = new DatePickerDialogFragment();
        f.setDateSetListener(listener);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(start);

        Bundle bundle = new Bundle(3);
        bundle.putInt(EXTRA_YEAR, calendar.get(Calendar.YEAR));
        bundle.putInt(EXTRA_MONTH, calendar.get(Calendar.MONTH));
        bundle.putInt(EXTRA_DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH));
        f.setArguments(bundle);
        return f;
    }

    /**
     * Create a TimePickerDialogFragment with an event listener. The default year/month/day will be the current date.
     * @param listener event listener
     * @return
     */
    public static DatePickerDialogFragment createDatePicker(DatePickerDialog.OnDateSetListener listener) {
        DatePickerDialogFragment f = new DatePickerDialogFragment();
        f.setDateSetListener(listener);
        return f;
    }


    public void setDateSetListener(DatePickerDialog.OnDateSetListener listener) {
        this.listener = listener;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        int year;
        int month;
        int dayOfMonth;

        if(savedInstanceState != null && savedInstanceState.containsKey(EXTRA_YEAR)) {
            year = savedInstanceState.getInt(EXTRA_YEAR);
            month = savedInstanceState.getInt(EXTRA_MONTH);
            dayOfMonth = savedInstanceState.getInt(EXTRA_DAY_OF_MONTH);
        }
        else {
            // Use the current time as the default values for the picker
            final Calendar c = Calendar.getInstance();
            year = c.get(Calendar.YEAR);
            month = c.get(Calendar.MONTH);
            dayOfMonth = c.get(Calendar.DAY_OF_MONTH);
        }

        // Create a new instance of TimePickerDialog and return it
        return new DatePickerDialog(getActivity(), listener, year, month, dayOfMonth);
    }
}
